# MLND-Capstone

My capstone project for Udacity's Machine Learning Nanodegree

**Topic:** TalkingData AdTracking Fraud Detection Challenge

## Dataset

The training and testing datasets for the Fraud Detection Challenge can be downloaded from [Kaggle's competition webpage](https://www.kaggle.com/c/talkingdata-adtracking-fraud-detection/data).
